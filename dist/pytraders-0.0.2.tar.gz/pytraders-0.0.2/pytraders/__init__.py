def my_coll_test():
    print("success")
# Weather Reporter

A Python package to get weather reports for any location.

## Usage

Following query on terminal will provide you the weather details of "delhi" for next 3 days.

```
weather-reporter -q delhi -d 3
```